# 订单工具边界

当前已知只读能力为 mcp__mcd-mcp__order-list，无参数；mcp__mcd-mcp__query-order，参数orderId字符串。始终先加载当前宿主工具声明，使用本次列表返回的真实orderId查询详情。

本发行包不提供认证凭证。官方 MCP Server 地址为 https://mcp.mcd.cn，使用 Streamable HTTP，并通过 `Authorization: Bearer <个人 MCP Token>` 认证。每位用户在 https://open.mcd.cn/mcp 登录并申请自己的 Token，再按 https://github.com/M-China/mcd-mcp-server 配置宿主。无工具时不得声称已经联网同步，不得要求用户在对话中粘贴 Token，也不要生成虚构安装链接。

完整数据格式参见 order-contract.md。只将筛选脱敏后的白名单数据交给本地构建器。
